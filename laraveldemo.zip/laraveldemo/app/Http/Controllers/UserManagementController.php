<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Category;
use App\User;
use DB;
use Illuminate\Support\Facades\Validator;

class UserManagementController extends Controller
{
    public function usermanagement()
    {
     $data['userdetails']  = User::all();
        return view('usermanagement',$data);
    }
   public function store_user(Request $request)
   {
    // dd($request->all());
    $txtid = $request->txtid;
    $txtusername = $request->txtusername;
    $txtemail = $request->txtemail;
    $txtyear = $request->txtyear;
    $txtmonth = $request->txtmonth;
    $txtimagename = $request->txtimagename;

    $user =  User::find($txtid); 
$messages = [
    'required' => 'This field is required.',
];
    $validator = Validator::make($request->all(), [
            'txtusername' => 'required|max:255',
            'username' => 'unique:user',
            'txtemail' => 'required',
            'txtyear' => 'required',
            'txtmonth' => 'required'
        ],$messages);

        if ($validator->fails()) {
            return redirect('/')
                        ->withErrors($validator)
                        ->withInput();
        }

    if($txtid == '0')
    {
          $user =  new User();
          $user->username = $txtusername;
           $user->email = $txtemail;
            $user->year = $txtyear;
             $user->month = $txtmonth;
             $user->profile_pic = $txtimagename;
             // dd($user);
              $user->save();
    }
    return redirect('/');
   }

   public function store_fileupload(Request $request)
   {
    $file = $request->txtimage;

     // $fileName = time().'.'.$request->file->extension();  
// $fileupload = new FileUpload();  

     if($files=$request->file('txtimage')){  
$name=$files->getClientOriginalName();  
$files->move(public_path('images'),$name);  
// $data->path=$name;  
}
    return response($name);

   
        

   }
   public function user_delete(Request $request,$id)
   {
      $user =  User::find($id);
      if(!empty($user))
      {
        $user->delete();
        $return['error'] = false;
      }
     
      return redirect('/');
   }
}
