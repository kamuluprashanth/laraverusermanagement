<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" >
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<style type="text/css">
		.img_profile{
    width: 50px;
    height: 50px;
    border-radius: 100%;
}
.verror
{
	color:red;
	display: block;
}
	</style>

</head>
<body>
<div class="container py-5">
  <div class="row">
  	
  
    <div class="col-12">
    	<div class="card" >
  <div class="card-header bg-primary text-white">
    User Management
    <button href="javascript:void(0);" class="btn btn-light float-right" data-toggle="modal" data-target="#staticBackdrop">Add</button>
  </div>

      <table class="table table-bordered">
        <thead>
          <tr>
            <th scope="col">Image</th>
            <th scope="col">Name</th>
            <th scope="col">Email</th>
            <th scope="col">Experience</th>
            <th scope="col">Actions</th>
          </tr>
        </thead>
        <tbody>
      <?php if(!empty($userdetails)): ?>
      <?php $__currentLoopData = $userdetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <th scope="row">
            	<?php if(substr($details->profile_pic, -3) =='jpg'||substr($details->profile_pic, -3) =='png'||substr($details->profile_pic, -3) =='gif' || $details->profile_pic != null): ?>
										<img src="<?php echo e(url('images').'/'.$details->profile_pic); ?>" alt="image missing" class="img-fluid img_profile">
									<?php else: ?>
									<img src="<?php echo e(url('/placeholder.jpg')); ?>" alt="image missing" class="img-fluid img_profile">
											
                               
									<?php endif; ?>
								

            </th>
            <td><?php echo e($details->username); ?></td>
            <td><?php echo e($details->email); ?></td>
            <td><?php echo e($details->year.' '.$details->month); ?></td>
            <td>          
            <a  href="<?php echo e(url('/userdelete/'.$details->id)); ?>"  class="btn btn-danger"><i class="fa fa-trash-o" aria-hidden="true"></i> Remove</a>
            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
</div>
<!-- Button trigger modal -->
<!-- <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#staticBackdrop">
  Launch static backdrop modal
</button> -->

<!-- Modal -->
<div class="modal fade" id="staticBackdrop" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header bg-primary text-white">
        <h5 class="modal-title" id="staticBackdropLabel">Add User</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
         <form action="<?php echo e(url('storeuser')); ?>" method="post" enctype="multipart/form-data" id="userform">
         		<input type="hidden" name="txtid" id="txtid" value="0">
      <div class="modal-body">
     
        	 <?php echo csrf_field(); ?>
          <div class="form-group">
            <label for="name" class="col-form-label">Name</label>
            <input type="text" class="form-control txtusername" name="txtusername" id="txtusername" placeholder="Name">
            <span class="verror"><?php if($errors->has('txtusername')): ?><?php echo e($errors->first('txtusername')); ?><?php endif; ?></span>
          </div>
          <div class="form-group">
            <label for="txtemail" class="col-form-label">Email</label>
            <input type="email" class="form-control txtemail" id="txtemail" name="txtemail" placeholder="Email">
            <span class="verror"><?php echo e($errors->first('txtemail')); ?></span>
          </div>
             <div class="form-group">
             	 <label for="txtexperience" class="col-form-label">Experience</label>
             	<div class="row">
             		<div class="col-md-6">             			
			            <select type="text" class="form-control txtexperience" name="txtyear" id="txtexperience">
			            	<option value="">Select Year</option>
			            </select>
			             <span class="verror"><?php echo e($errors->first('txtyear')); ?></span>
             		</div>
             		<div class="col-md-6">             			
			           <select type="text" class="form-control txtmonth" name="txtmonth" id="txtmonth">
			            	<option value="">Select Month</option>
			            </select>
			            <span class="verror"><?php echo e($errors->first('txtmonth')); ?></span>
             		</div>
             	</div>
           
          </div>
          
           
           <div class="form-group">
           	<input type="hidden" name="txtimagename" id="txtimagename" value="">
            <label for="txtemail" class="col-form-label" style="display: block;">Image</label>
            <input type="file" class="txtimage" id="txtimage" name="txtimage" >
          </div>
         
       
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Save</button>
      </div>
       </form>
    </div>
  </div>
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js" ></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

	<?php if(count($errors) > 0): ?>

<script type="text/javascript">
	$('#staticBackdrop').modal('show');
</script>
  	<?php endif; ?>
   <script type="text/javascript" >
    var url = <?php echo json_encode(url('/')); ?>;
</script> 
<script type="text/javascript">
	for (var i = 0; i <= 12; i++) {
		$("#txtexperience").append(new Option(""+i+" year", ""+i+" year"));
	}
		for (var i = 0; i <= 12; i++) {
		$("#txtmonth").append(new Option(""+i+" month", ""+i+" month"));
	}
	
$('body').on('change','#txtimage',function(){

              
var formData = new FormData();

// Attach file
formData.append('txtimage', $('input[type=file]')[0].files[0]); 
formData.append('_token', $("input[name='_token']").val()); 
               // var form = $('#KeyskillsFormid')[0];
               // var data = new FormData(form);
        $.ajax({
      url : url + '/storefileupload',
      enctype: 'multipart/form-data',
      processData: false,
            contentType: false,
            cache: false,
      type : 'POST',
      data : formData,

         success : function(response) {
         	alert('hello');
        $('#txtimagename').attr('value',response);

      }, error : function(xhr, status, error) {
        console.log(xhr.responseText);
      }
    });


 
});
  	
 

  
</script>
</body>
</html><?php /**PATH C:\xampp\htdocs\laraveldemo\resources\views/usermanagement.blade.php ENDPATH**/ ?>